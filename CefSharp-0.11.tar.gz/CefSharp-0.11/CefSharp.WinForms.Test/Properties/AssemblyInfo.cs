﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.WinForms.Test")]
[assembly: AssemblyCompany("Anthony Taranto")]
[assembly: AssemblyProduct("CefSharp.Example")]
[assembly: AssemblyCopyright("Copyright © 2012")]

[assembly: AssemblyVersion("0.11.*")]
[assembly: ComVisible(false)]