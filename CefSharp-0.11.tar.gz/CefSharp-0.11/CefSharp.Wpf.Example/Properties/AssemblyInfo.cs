﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.Wpf.Example")]
[assembly: AssemblyCompany("Anthony Taranto")]
[assembly: AssemblyProduct("CefSharp")]
[assembly: AssemblyCopyright("Copyright © Anthony Taranto 2012")]

[assembly: AssemblyVersion("0.11.*")]
[assembly: ComVisible(false)]
